# Prompt: apply the attendance calculation changes

You are editing an existing Android app (Kotlin, Jetpack Compose, Room, Firebase), package `com.example`, source root `app/src/main/java/com/example/`. Apply the 19 changes below exactly as written. Do not change anything else. Do not touch the database schema, saved records, themes, or any screen not named here.

## How to apply

1. Preferred: apply `attendance_changes.patch` from the project root (the folder that contains `app/`):
   `patch -p1 < attendance_changes.patch`  (or `git apply -p1 attendance_changes.patch`)
   It was tested against the original project and applies with no fuzz or rejects.
2. If the patch cannot be applied, copy each file from `changed_files/` over the file with the same path in the project. These are the complete final versions of the 13 edited files, plus one new test file.
3. After applying, build (`./gradlew assembleDebug`) and run the unit tests (`./gradlew testDebugUnitTest`). Fix only compile errors caused by these changes. Report anything you could not verify.

## Changes (all 19 must be present when you finish)

Paths below are relative to `app/src/main/java/com/example/`.

1. **Tutorial = part of its lecture subject** (`data/util/AttendanceCalculationEngine.kt`)
   Add `TUTORIAL_SUFFIX` regex, `canonicalSubjectCode()` and `isTutorialSession()`. `isLabSession()` returns false for tutorials. In `calculateOverallStats`, group subjects by `canonicalSubjectCode(rec.subjectCode)` so "BHT502" and "BHT502-T" form one subject with one percentage. Prefer the lecture's code and name for display. `SubjectAccumulator.code` and `.name` become `var`, and it gains `var fromTutorial`.

2. **Whole-word lab detection** (same file)
   Replace the `contains("LAB")`, `contains("PRAC")`, `contains("PRACTICAL")` and `contains("LABORATORY")` checks with `LAB_CODE` and `LAB_WORD` regexes so names like "Collaborative" are not labs.

3. **Per-subject upcoming weights** (`AttendanceCalculationEngine.kt`, `data/repository/AttendanceRepository.kt`)
   `calculateOverallStats` and `AttendanceRepository.calculateStatistics` take a new parameter `upcomingWeightsBySubject: Map<String, List<Float>> = emptyMap()`. Subject recovery and safe-miss pass `upcomingWeights = upcomingWeightsBySubject[canonicalSubjectCode(code)]`. Auto-credited subjects get safe-miss 0.

4. **Exact percentage and estimate flag** (`data/model/Entities.kt`, engine)
   Add `percentageExact: Double` and `isEstimate: Boolean` to `SubjectAttendanceStat` and `OverallAttendanceStat`. Fill them in the engine (`isEstimate = upcomingWeights.isEmpty()` for overall, `false` per subject).

5. **Single definition of "below target"** (`Entities.kt`, engine, `ui/screens/ReportsScreen.kt`)
   `OverallAttendanceStat.isBelowTarget` and the per-subject `isBelowTarget` are true only for the WARNING or SHORTFALL tier. Add `OverallAttendanceStat.hasData`. `ReportsScreen` uses `stat.isBelowTarget`.

6. **Shared helpers** (engine)
   Add `weightedTotals(records): Pair<Double, Double>` (attended, conducted) and `upcomingWeights(slotsByDay, startDate, holidayDates, horizonDays = 120)`. The second returns the overall list and a per-subject map, in timetable order, skipping holidays, non-counting slots, doubt-clearing, auto-credited slots and zero weights.

7. **View model uses the real timetable** (`ui/viewmodel/AttendanceViewModel.kt`)
   Move `allSlotsForCurrentVersion` above `overallStats`. Add `upcomingWeightsFlow` (combine slots, profile, overrides; filter by batch and academic category; collect holidays for 120 days including `AktuHolidays.isOfficialHoliday`). `overallStats` combines records, profile and `upcomingWeightsFlow` and passes them to `repository.calculateStatistics`. `monthlyAttendanceSummary` becomes `StateFlow<Pair<Double, Double>>` and uses `AttendanceCalculationEngine.weightedTotals`.

8. **No Data and (estimate) on screen** (`ui/components/CommonComponents.kt`, `ui/screens/HomeScreen.kt`, `ReportsScreen.kt`)
   The summary card takes `exactPercentage` and `isEstimate`. It shows "No Data" when nothing is conducted, uses the exact percentage for eligibility, and appends " (estimate)" to the recovery and safe-miss messages when `isEstimate`. `HomeScreen` shows "No Data" instead of 0% in two places and appends the estimate label. `ReportsScreen` passes `stats.percentageExact` and `stats.isEstimate`.

9. **Notifications use tiers** (`data/notification/NotificationAutomationHelper.kt`)
   The low-attendance warning fires on WARNING or SHORTFALL. The weekly report and sample notification compare `stats.percentageExact` to the target.

10. **What-If uses weights** (`ui/screens/whatif/WhatIfModels.kt`, `ui/screens/whatif/WhatIfPredictorScreen.kt`)
    `WhatIfSubjectImpact` attended and conducted fields become `Double`. Percentages come from `AttendanceCalculationEngine.calculatePercentage`. `computePrediction()` tallies by `canonicalSubjectCode`, starts from the engine's weighted subject stats, adds `resolveSessionWeight(...)` for each planned class, adds auto-credited classes to attended and conducted equally, and computes overall from combined totals.

11. **5-point amber band** (`ui/components/Animations.kt`)
    In `AnimatedCircularAttendanceRing` and `AnimatedHorizontalProgressBar`, change `target - 10f` to `target - 5f`.

12. **CSV status from tier** (`AttendanceRepository.kt`)
    In `generateCsvReport`, the overall and per-subject status come from `statusTier` (SAFE / NO_DATA / otherwise shortage), not a rounded percentage.

13. **Settings card** (`ui/screens/SettingsScreen.kt`, `SettingsGlassCard` only)
    Replace the Surface-and-inner-Box with one `Box`: `fillMaxWidth`, `clip(RoundedCornerShape(20.dp))`, `background(GlassTokens.surfaceBrush(isDark))`, `border(BorderStroke(0.dp, borderBrush), shape)`, `padding(16.dp)`. `borderBrush` is a linear gradient: dark `0x454A6EFF` to `0x1A4A6EFF`, light `0x332563EB` to `0x142563EB`. Remove `shadowElevation` and `GlassTokens.borderColor` from this composable. Use `fillMaxWidth`, not `fillMaxSize`, because the card sits in a scrolling column.

14. **Remove the floating Add Class button** (`ui/screens/TimetableScreen.kt`)
    Delete the floating `Surface` (gradient pill with test tag `btn_add_class`) and the unused `FloatingActionButton` import. Keep the inline "Add Class to <day>" button at the bottom of the list.

15. **Tests** (new files `app/src/test/java/com/example/data/util/AttendanceCalculationEngineTest.kt` and `app/src/test/java/com/example/ui/viewmodel/LabBlockMergeTest.kt`, `app/src/test/java/com/example/data/local/InitialTimetableDataTest.kt`, `app/src/test/java/com/example/data/util/LabBlockRecordsTest.kt`, `app/src/test/java/com/example/ui/screens/whatif/WhatIfLabMergeTest.kt`)
    32 JUnit tests in total (18 engine, 4 daily lab-merge, 3 timetable, 4 report lab-merge, 3 What-If lab-merge): theory, lab block, legacy lab weight, absent lab block, lab word match, auto-credit, cancelled and unmarked, zero classes, tutorial merge, pooled overall, tier boundaries (75 and 90), recovery (equal and mixed weights), safe-miss (boundary and mixed weights), estimate flag, `weightedTotals` matches master stats. All must pass.

16. **A lab block is 2 credits, one credit per period** (`data/util/AttendanceCalculationEngine.kt`, `data/repository/AttendanceRepository.kt` comment)
    A lab spans two periods and is worth 2 credits in total, the same as two normal classes. `resolveSessionWeight()` returns `DEFAULT_LAB_PERIOD_WEIGHT = 1.0` for any lab period and checks this first, so records saved earlier with a stored weight of 2.0 are not counted twice. `DEFAULT_LAB_WEIGHT` is replaced by `DEFAULT_LAB_PERIOD_WEIGHT` and `LAB_BLOCK_CREDITS = 2.0`. Past records are not rewritten; existing lab records are re-read at the new weight automatically.

17. **One present/absent control per lab block** (new file `ui/viewmodel/DailyAttendanceUiItem.kt`, edits in `ui/viewmodel/AttendanceViewModel.kt`)
    Move `DailyAttendanceUiItem` into its own file (same package) and add `pairedPeriod: Int? = null`. Add `mergeLabBlocks()`, which merges two consecutive lab periods of the same subject into one item (label "III–IV", start of the first period to end of the second; unmarked if the two saved statuses differ), and `expandLabBlocks()`, which reverses it. `buildDailyItems` returns `mergeLabBlocks(...)`. `markStatus` writes or clears the record for both periods. `markAllPresentForDate`, `markAllAbsentForDate` and `markAllCancelledForDate` start from `expandLabBlocks(dailyAttendanceItems.value)` so both lab periods are still saved. The two period records per lab stay in the database, so the unique (date, period) index and existing history are untouched. 

18. **Remove Swachhta Abhiyan and doubt clearing** (`data/local/InitialTimetableData.kt`, `data/util/AttendanceCalculationEngine.kt`, `data/local/Daos.kt`, `data/repository/AttendanceRepository.kt`, `ui/viewmodel/AttendanceViewModel.kt`, `ui/screens/whatif/WhatIfPredictorScreen.kt`)
    Delete the five slots from the default timetable: `SWACH` on Monday period 8 and `DOUBT` on period 8 of Tuesday to Friday. In the engine, `isExcludedFromAttendance()` now also returns true for `SWACH` / "Swachh…", and `isAutoCredited()` no longer treats Swachhta as auto-credited. Add DAO query `deleteRemovedSessionSlots()` (deletes timetable slots whose code is SWACH or DOUBT; no schema change) and call it in `initializeDefaultsIfNeeded()` so an already-installed timetable is cleaned. `buildDailyItems` (both loops) and the What-If class list skip any excluded session. Saved attendance records for these sessions are not deleted; they are simply ignored by every calculation. The result is 7 credits on every teaching day for both batches, so October 2026 (20 teaching days) has 140 credits.

19. **Merge lab periods in Reports and What-If** (new file `data/util/LabBlockRecords.kt`; edits in `ui/screens/ReportsScreen.kt`, `ui/screens/whatif/WhatIfModels.kt`, `ui/screens/whatif/WhatIfPredictorScreen.kt`)
    Reports: add `AttendanceLogEntry` and `mergeLabRecords(records)`, which lists two back-to-back lab records of the same date, subject and status as one entry labelled "Period 3–4". The History tab and the date-inspect dialog use these entries. Nothing in the database changes, and records with different statuses stay separate. What-If: `WhatIfClassItem` gains `periodCount` (default 1) and `mergeWhatIfLabBlocks()` joins two consecutive periods of the same lab into one selectable class worth 2 periods, shown as one card with a combined label and time range. `getClassesForDate` returns the merged list. `computePrediction` multiplies the session weight by `periodCount` and adds `periodCount` to planned, missed and total-missed counts, so skipping one lab block costs 2 credits. `WhatIfDayPlan.missedCount` and `attendedCount` also sum `periodCount`, and the "classes selected" total on the select screen does too.

## Rules that must hold everywhere (check after applying)

- Weighted % = weighted attended ÷ weighted conducted × 100, per subject and overall (overall from combined totals).
- Theory = 1. A lab block (two periods) = 2 credits, one per period. Library and seminar are auto-credited. Cancelled, doubt-clearing and Swachhta sessions do not exist or count. Unmarked stays pending. Tutorial belongs to its lecture subject.
- Status: Safe at or above target, Warning up to 5 points below, Shortfall more than 5 below, compared unrounded. No Data when nothing is conducted.
- Recovery = ceil((T·C − A) ÷ (1 − T)) for equal weights, otherwise walk the real upcoming weights. Safe-miss = floor((A − T·C) ÷ (T·w)).
- Existing records, the Room schema and the light and dark themes are unchanged.
